create view piep as
select `bioinfadmin`.`piep`.`piep_id`     AS `piep_id`,
       `bioinfadmin`.`piep`.`bericht`     AS `bericht`,
       `bioinfadmin`.`piep`.`datum`       AS `datum`,
       `bioinfadmin`.`piep`.`tijd`        AS `tijd`,
       `bioinfadmin`.`piep`.`student_nr`  AS `student_nr`,
       `bioinfadmin`.`piep`.`ref_piep_id` AS `ref_piep_id`
from `bioinfadmin`.`piep`;

