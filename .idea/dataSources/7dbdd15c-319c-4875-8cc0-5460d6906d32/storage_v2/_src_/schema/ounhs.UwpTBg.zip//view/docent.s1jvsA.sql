create view docent as
select `bioinfadmin`.`docent`.`slb_id`         AS `slb_id`,
       `bioinfadmin`.`docent`.`voornaam`       AS `voornaam`,
       `bioinfadmin`.`docent`.`tussenvoegsels` AS `tussenvoegsels`,
       `bioinfadmin`.`docent`.`achternaam`     AS `achternaam`
from `bioinfadmin`.`docent`;

