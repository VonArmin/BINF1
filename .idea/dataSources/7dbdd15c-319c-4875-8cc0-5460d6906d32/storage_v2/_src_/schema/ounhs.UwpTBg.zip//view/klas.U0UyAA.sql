create view klas as
select `bioinfadmin`.`klas`.`klas_id` AS `klas_id`, `bioinfadmin`.`klas`.`klas_naam` AS `klas_naam`
from `bioinfadmin`.`klas`;

