create view leuk as
select `bioinfadmin`.`leuk`.`id`         AS `id`,
       `bioinfadmin`.`leuk`.`value`      AS `value`,
       `bioinfadmin`.`leuk`.`piep_id`    AS `piep_id`,
       `bioinfadmin`.`leuk`.`student_nr` AS `student_nr`
from `bioinfadmin`.`leuk`;

